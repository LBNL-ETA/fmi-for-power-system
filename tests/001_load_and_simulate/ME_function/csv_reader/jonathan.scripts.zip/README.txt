IMPORTANT:

The files contains in this folder must be added to the PYTHONPATH.
This can be done by adding the unzipped folder jonathan.scripts to the PYTHONPATH.

