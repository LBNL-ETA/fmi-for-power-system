IMPORTANT:

The files contains in this folder must be added to the system PATH.
This can be done by adding subdirectories of the unzipped folder multiplier.binaries to the system PATH.

